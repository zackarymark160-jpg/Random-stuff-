SUN PRAIRIE ALPR: LIGHT PUBLIC EDITION (v3.1, November 2026)

An independent, unofficial record by Zack Mark, a student. Not affiliated with the City of Sun Prairie or the Sun Prairie Police Department.
Contact: sunprairiealpr@gmail.com

01_Volumes   ALPR volume (187 pages) and the 2-page summary
02_Handouts  Flyer, press kit, ALPR handout, overview
03_Extras    Email-size ALPR volume and a text-only version

Large-print versions, single-section PDFs and the Student Voice volume are on the website: sunprairiealpr.netlify.app
Facts come from public documents and are labeled as written documents, statements or open questions. I take no side.
I use AI tools to help draft and format, and I check facts against the sources. Corrections: sunprairiealpr.netlify.app
